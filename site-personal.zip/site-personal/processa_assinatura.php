<?php
session_start();
include 'conexao.php';
include 'classes/Assinatura.php';

if (!isset($_SESSION['usuario'])) {
    header("Location: entrar.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $plano = $_POST['plano'];
    $id_usuario = $_SESSION['usuario']['id'];
    
    $valores = [
        'Essencial' => 119.90,
        'Avancado' => 99.90,
        'Premium' => 79.90
    ];
    
    $valor = $valores[$plano];
    $transacao = uniqid();
    
    try {
        // Usando a classe Assinatura (POO)
        $assinatura = new Assinatura([
            'id_usuario' => $id_usuario,
            'plano' => $plano,
            'valor' => $valor,
            'transacao' => $transacao
        ]);
        
        if ($assinatura->salvar($pdo)) {
            header("Location: pagamento.php?plano=" . urlencode($plano) . "&transacao=" . $transacao);
            exit();
        } else {
            throw new Exception("Erro ao salvar assinatura");
        }
    } catch (Exception $e) {
        $erro = "Erro ao processar assinatura. Tente novamente.";
        error_log($e->getMessage());
    }
}
?>