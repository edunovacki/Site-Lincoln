<footer>
      <p>Desenvolvido Por Lincoln Tonolo - Todos os Direitos Reservados</p>
      <div class="icones">
      <a href="https://www.instagram.com/lincoln_tonolo/" target="_blank"><i class="fa-brands fa-instagram icones"></i></a>
      <a href="https://wa.me/5544997686749" target="_blank"><i class="fa-brands fa-whatsapp"></i></a>
    </div>
    </footer>