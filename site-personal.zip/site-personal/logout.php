<?php
/*session_start();
// Destruir todas as variáveis de sessão
$_SESSION = array();

// Destruir a sessão
session_destroy();

// Redirecionar para index.php
header("Location: index.php");
exit();*/



session_start();

// Verificar se é admin e destruir apenas a sessão admin
if (isset($_SESSION['admin'])) {
    unset($_SESSION['admin']);
}

// Ou destruir completamente a sessão
session_destroy();

// Redirecionar para index.php
header("Location: index.php");
exit();


?>