<?php
include 'conexao.php';

try {
    $stmt = $pdo->query("SELECT NOW() as data_atual");
    $resultado = $stmt->fetch();
    echo "Conexão bem-sucedida! Data/hora do servidor: " . $resultado['data_atual'];
} catch (PDOException $e) {
    echo "Erro de conexão: " . $e->getMessage();
}
?>