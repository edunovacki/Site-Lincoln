<?php
session_start();
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: index.php");
    exit();
}

include 'conexao.php';

// Buscar estatísticas
$stmt = $pdo->query("SELECT COUNT(*) as total FROM assinaturas WHERE status_pagamento = 'pago'");
$total_assinaturas = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT SUM(valor) as lucro FROM assinaturas WHERE status_pagamento = 'pago'");
$lucro = $stmt->fetch()['lucro'];

// Buscar assinaturas
$stmt = $pdo->query("SELECT a.*, u.nome as usuario_nome FROM assinaturas a JOIN usuarios u ON a.id_usuario = u.id");
$assinaturas = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrador</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="CSS/administrador.css">
</head>
<body>
    <div class="admin-container">
        <div class="sidebar">
            <h2>Admin</h2>
            <ul>
                <li><a href="#" class="active" data-target="lucro">Lucro</a></li>
                <li><a href="#" data-target="planos">Planos</a></li>
                <li><a href="logout.php">Sair</a></li>
            </ul>
        </div>
        <div class="main-content">
            <div class="stats">
                <div class="stat-card">
                    <h3>Lucro Total</h3>
                    <p>R$ <?php echo number_format($lucro, 2, ',', '.'); ?></p>
                </div>
                <div class="stat-card">
                    <h3>Total de Assinaturas</h3>
                    <p><?php echo $total_assinaturas; ?></p>
                </div>
            </div>
            <div class="content-section" id="lucro">
                <h2>Lista de Assinaturas</h2>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>Plano</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($assinaturas as $assinatura): ?>
                        <tr>
                            <td><?php echo $assinatura['usuario_nome']; ?></td>
                            <td><?php echo $assinatura['plano']; ?></td>
                            <td><span class="status <?php echo $assinatura['status_pagamento']; ?>"><?php echo $assinatura['status_pagamento']; ?></span></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="content-section" id="planos" style="display:none;">
                <h2>Planos e Assinantes</h2>
                <!-- Conteúdo para planos -->
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.querySelectorAll('.sidebar a').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const target = this.getAttribute('data-target');
                document.querySelectorAll('.content-section').forEach(section => {
                    section.style.display = 'none';
                });
                document.getElementById(target).style.display = 'block';
                document.querySelectorAll('.sidebar a').forEach(a => a.classList.remove('active'));
                this.classList.add('active');
            });
        });
    </script>
</body>
</html>