<?php
session_start();
include 'conexao.php';

if (!isset($_SESSION['usuario'])) {
    header("Location: entrar.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $plano = $_POST['plano'];
    $id_usuario = $_SESSION['usuario']['id'];
    
    $valores = [
        'Essencial' => 119.90,
        'Avancado' => 99.90,
        'Premium' => 79.90
    ];
    
    $valor = $valores[$plano];
    $transacao = uniqid();
    
    try {
        $stmt = $pdo->prepare("INSERT INTO assinaturas (id_usuario, plano, valor, transacao) VALUES (?, ?, ?, ?)");
        $stmt->execute([$id_usuario, $plano, $valor, $transacao]);
        
        header("Location: pagamento.php?plano=" . urlencode($plano) . "&transacao=" . $transacao);
        exit();
    } catch (PDOException $e) {
        $erro = "Erro ao processar assinatura. Tente novamente.";
    }
}
?>