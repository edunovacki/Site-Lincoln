<?php
session_start();
include 'conexao.php';

if (!isset($_SESSION['usuario'])) {
    header("Location: entrar.php");
    exit();
}

$plano = $_GET['plano'] ?? '';
$transacao = $_GET['transacao'] ?? '';

$valores = [
    'Essencial' => 119.90,
    'Avancado' => 99.90,
    'Premium' => 79.90
];

$valor = $valores[$plano] ?? 0;
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagamento - <?php echo $plano; ?></title>
    <link rel="stylesheet" href="CSS/pagamento.css">
</head>
<body>
    <div class="container">
        <h1>Pagamento - Plano <?php echo $plano; ?></h1>
        <div class="plano-info">
            Valor: R$ <?php echo number_format($valor, 2, ',', '.'); ?>
        </div>
        
        <div class="qrcode-container">
            <img src="gerar_qrcode.php?plano=<?php echo urlencode($plano); ?>" alt="QR Code PIX">
        </div>
        
        <div class="chave-pix">
            <p>Chave PIX: 2dab3619-c348-4040-8ce3-6b064d5302b2 </span> <button onclick="copiarChave()">Copiar</button></p>
        </div>
        
        <a href="index.php" class="btn-voltar">Voltar para o Início</a>
    </div>
    <script>
        function copiarChave() {
            const chave = document.getElementById('chave').innerText;
            navigator.clipboard.writeText(chave).then(() => {
                alert('Chave PIX copiada!');
            });
        }
    </script>
</body>
</html>