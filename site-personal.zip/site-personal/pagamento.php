<?php
$plano = $_GET['plano'] ?? '';
$valores = [
    'Essencial' => 119.90,
    'Avançado' => 99.90,
    'Premium' => 79.90
];
$valor = $valores[$plano] ?? 0;
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagamento - <?php echo $plano; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="CSS/pagamento.css" />
</head>
<body>
    <div class="container">
        <h1>Plano <?php echo $plano; ?> - R$ <?php echo number_format($valor, 2, ',', '.'); ?></h1>
        <p>Escaneie o QR Code abaixo para pagar via PIX</p>
        <div class="qrcode">
            <img src="gerar_qrcode.php?plano=<?php echo urlencode($plano); ?>" alt="QR Code para pagamento">
        </div>
        <div class="chave-pix">
            <p>Chave PIX: <span id="chave">2dab3619-c348-4040-8ce3-6b064d5302b2</span> <button onclick="copiarChave()">Copiar</button></p>
        </div>
    </div>

    <script>
        function copiarChave() {
            const chave = document.getElementById('chave').innerText;
            navigator.clipboard.writeText(chave).then(() => {
                alert('Chave PIX copiada!');
            });
        }
    </script>
</body>
</html>