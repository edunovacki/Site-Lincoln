<?php
include 'conexao.php';

$stmt = $pdo->query("SELECT * FROM administradores");
$administradores = $stmt->fetchAll();

echo "Administradores cadastrados:<br>";
foreach ($administradores as $admin) {
    echo "ID: " . $admin['id'] . " - Usuário: " . $admin['usuario'] . "<br>";
}
?>