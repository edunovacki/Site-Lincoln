<?php
class Usuario {
    private $id;
    private $email;
    private $senha;
    private $nome;
    private $idade;
    private $sexo;

    public function __construct($dados = []) {
        if (!empty($dados)) {
            $this->id = $dados['id'] ?? null;
            $this->email = $dados['email'] ?? '';
            $this->senha = $dados['senha'] ?? '';
            $this->nome = $dados['nome'] ?? '';
            $this->idade = $dados['idade'] ?? '';
            $this->sexo = $dados['sexo'] ?? '';
        }
    }

    // Getters e Setters
    public function getId() { return $this->id; }
    public function getEmail() { return $this->email; }
    public function setEmail($email) { $this->email = $email; }
    // ... outros getters e setters

    public function salvar($pdo) {
        try {
            if ($this->id) {
                // Update
                $stmt = $pdo->prepare("UPDATE usuarios SET email=?, nome=?, idade=?, sexo=? WHERE id=?");
                $stmt->execute([$this->email, $this->nome, $this->idade, $this->sexo, $this->id]);
            } else {
                // Insert
                $stmt = $pdo->prepare("INSERT INTO usuarios (email, senha, nome, idade, sexo) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$this->email, $this->senha, $this->nome, $this->idade, $this->sexo]);
                $this->id = $pdo->lastInsertId();
            }
            return true;
        } catch (PDOException $e) {
            error_log("Erro ao salvar usuário: " . $e->getMessage());
            return false;
        }
    }

    public static function buscarPorEmail($pdo, $email) {
        try {
            $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ?");
            $stmt->execute([$email]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Erro ao buscar usuário: " . $e->getMessage());
            return false;
        }
    }
}
?>