<?php
// classes/Assinatura.php
class Assinatura {
    private $dados;

    public function __construct($dados) {
        $this->dados = $dados;
    }

    public function salvar($pdo) {
        $sql = "INSERT INTO assinaturas (id_usuario, plano, valor, transacao, status_pagamento) 
                VALUES (?, ?, ?, ?, 'andamento')";
        $stmt = $pdo->prepare($sql);
        return $stmt->execute([
            $this->dados['id_usuario'],
            $this->dados['plano'],
            $this->dados['valor'],
            $this->dados['transacao']
        ]);
    }
}
?>