# Modelo Entidade-Relacionamento

## Entidades:

### usuarios
- id (PK, INT)
- email (VARCHAR)
- senha (VARCHAR)
- nome (VARCHAR)
- idade (INT)
- sexo (CHAR)

### assinaturas
- id (PK, INT)
- id_usuario (FK, INT) → usuarios.id
- plano (VARCHAR)
- valor (DECIMAL)
- transacao (VARCHAR)
- data_criacao (DATETIME)

## Relacionamentos:
- Um usuário pode ter várias assinaturas (1:N)