<?php
session_start();
?>
<header>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="index.php" class="nav-link"><i class="fa-solid fa-house"></i> Home</a>
          </li>
          <li class="nav-item">
            <a href="sobre.php" class="nav-link"><i class="fa-solid fa-user"></i> Sobre Mim</a>
          </li>
          <li class="nav-item">
            <a href="planos.php" class="nav-link"><i class="fa-solid fa-credit-card"></i> Planos</a>
          </li>
          <li class="nav-item">
            <a href="contato.php" class="nav-link"><i class="fa-solid fa-envelope"></i> Contato</a>
          </li>
          <?php if (isset($_SESSION['usuario'])): ?>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <i class="fa-solid fa-user"></i> Perfil
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
              <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#modalPerfil">Informações</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item text-danger" href="logout.php">Sair</a></li>
            </ul>
          </li>
          <?php else: ?>
          <li class="nav-item">
            <a href="entrar.php" class="nav-link"><i class="fa-solid fa-right-to-bracket"></i> Entrar</a>
          </li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </nav>
  <?php if (isset($_SESSION['usuario'])): ?>
<!-- Modal -->
<div class="modal fade" id="modalPerfil" tabindex="-1" aria-labelledby="modalPerfilLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalPerfilLabel">Informações do Perfil</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="text-center mb-3">
          <img src="https://via.placeholder.com/100" class="rounded-circle" alt="Foto de perfil">
        </div>
        <p><strong>Nome:</strong> <?php echo $_SESSION['usuario']['nome']; ?></p>
        <p><strong>Email:</strong> <?php echo $_SESSION['usuario']['email']; ?></p>
        <p><strong>Idade:</strong> <?php echo $_SESSION['usuario']['idade']; ?></p>
        <p><strong>Sexo:</strong> <?php echo $_SESSION['usuario']['sexo']; ?></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>
</header>