<?php
session_start();
include 'conexao.php';
include 'classes/Usuario.php';

$erro = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    // Verificar se é o admin
    if ($email == 'edunovacki' && $senha == '0123') {
        $_SESSION['admin'] = true;
        header("Location: administrador.php");
        exit();
    }

    try {
        // Usando a classe Usuario (POO)
        $usuarioData = Usuario::buscarPorEmail($pdo, $email);
        
        if ($usuarioData && password_verify($senha, $usuarioData['senha'])) {
            $_SESSION['usuario'] = $usuarioData;
            header("Location: index.php");
            exit();
        } else {
            $erro = "Email ou senha incorretos.";
        }
    } catch (Exception $e) {
        error_log("Erro no login: " . $e->getMessage());
        $erro = "Erro interno do sistema. Tente novamente.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="CSS/entrar.css"/>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bangers&family=Edu+VIC+WA+NT+Hand:wght@400..700&display=swap" rel="stylesheet">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bangers&family=Edu+VIC+WA+NT+Hand:wght@400..700&family=IBM+Plex+Sans:ital,wght@0,100..700;1,100..700&display=swap" rel="stylesheet">
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel="stylesheet">
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

    <title>Personal Trainer</title>

  </head>
  <body>
    <main class="container">
        <form action="entrar.php" method="post">
            <h1>Login</h1>
            <div class="input-box"><input name="email" placeholder="E-mail" type="text" required><i class="fa-solid fa-user"></i>
            <?php if (isset($erro) && $erro != ''): ?>
        <div class="alert" role="alert">
            <?php echo $erro; ?>
        </div>
    <?php endif; ?>
        </div>
            <div class="input-box"><input name="senha" placeholder="Senha" type="password" required><i class="fa-solid fa-lock"></i></div>
            <!--<div class="remember-forgot"><label><input type="checkbox"> Lembrar senha</label><a href="#">Esqueci a senha</a></div>!-->
            <button type="submit" class="login">Login</button>
            <div class="register-link">
                <p>Não tem uma conta?<a href="cadastrar.php"> Cadastre-se<a></p>
            </div>
        </form>
    </main>
    <!--<?php 
          include 'footer.php';
    ?>!-->
    <script src="https://kit.fontawesome.com/83f4c4a578.js" crossorigin="anonymous"></script>
    <script>
  AOS.init();
</script>

<script>
// Limpar parâmetros da URL ao carregar a página
if (window.history.replaceState) {
    window.history.replaceState(null, null, window.location.href.split('?')[0]);
}
</script>
  </body>
</html>
