<?php
include('phpqrcode/qrlib.php');

// Parâmetros: plano e valor
$plano = $_GET['plano'] ?? '';
$valores = [
    'Essencial' => 119.90,
    'Avancado' => 99.90,
    'Premium' => 79.90
];
$valor = $valores[$plano] ?? 0;

// Texto para o QR Code do PIX
$chave_pix = "2dab3619-c348-4040-8ce3-6b064d5302b2";
$nome_beneficiario = "Eduardo Novacki";
$cidade = "Campo Mourão";
$valor_formatado = number_format($valor, 2, '.', '');

// Formato do payload PIX
$pix_code = "00020126580014BR.GOV.BCB.PIX0136{$chave_pix}520400005303986540{$valor_formatado}5802BR5925{$nome_beneficiario}6008{$cidade}62070503***6304";

// Gera o QR Code
QRcode::png($pix_code, false, QR_ECLEVEL_L, 10);
header('Content-Type: image/png');


?>