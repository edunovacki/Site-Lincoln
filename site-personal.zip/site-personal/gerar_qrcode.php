<?php
include('phpqrcode/qrlib.php');

// Parâmetros: plano e valor
$plano = $_GET['plano'] ?? '';
$valores = [
    'Essencial' => 119.90,
    'Avançado' => 99.90,
    'Premium' => 79.90
];
$valor = $valores[$plano] ?? 0;

// Gera um identificador único para a transação
$transacao = uniqid();

// Texto para o QR Code do PIX (em formato de string copia e cola)
$chave_pix = "2dab3619-c348-4040-8ce3-6b064d5302b2";
$nome_beneficiario = "Eduardo Novacki";
$cidade = "Campo Mourão";
$valor_formatado = number_format($valor, 2, '.', '');
$texto_pix = "00020126580014BR.GOV.BCB.PIX0136{$chave_pix}520400005303986540{$valor_formatado}5802BR5925{$nome_beneficiario}6008{$cidade}62070503***6304";

// Gera o QR Code
QRcode::png($texto_pix, false, QR_ECLEVEL_L, 10);
?>