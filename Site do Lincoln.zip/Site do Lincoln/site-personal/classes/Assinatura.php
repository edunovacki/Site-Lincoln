<?php
class Assinatura {
    private $dados;

    public function __construct($dados) {
        $this->dados = $dados;
    }

    public function salvar($pdo) {
        $sql = "INSERT INTO assinaturas (id_usuario, plano, valor, transacao, metodo_pagamento, status_pagamento) 
                VALUES (?, ?, ?, ?, 'PIX', 'andamento')";
        $stmt = $pdo->prepare($sql);
        return $stmt->execute([
            $this->dados['id_usuario'],
            $this->dados['plano'],
            $this->dados['valor'],
            $this->dados['transacao']
        ]);
    }

    public static function marcarComoPago($pdo, $transacao, $id_usuario) {
        // Iniciar transação para garantir consistência
        $pdo->beginTransaction();
        
        try {
            // Primeiro, cancelar todas as assinaturas anteriores do usuário
            $sqlCancelar = "UPDATE assinaturas SET status_pagamento = 'cancelado' WHERE id_usuario = ? AND status_pagamento = 'pago'";
            $stmtCancelar = $pdo->prepare($sqlCancelar);
            $stmtCancelar->execute([$id_usuario]);
            
            // Agora marcar a nova assinatura como paga
            $sql = "UPDATE assinaturas SET status_pagamento = 'pago', data_pagamento = NOW() WHERE transacao = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$transacao]);
            
            $pdo->commit();
            return true;
        } catch (Exception $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    public static function cancelarAssinatura($pdo, $transacao) {
        $sql = "DELETE FROM assinaturas WHERE transacao = ? AND status_pagamento = 'andamento'";
        $stmt = $pdo->prepare($sql);
        return $stmt->execute([$transacao]);
    }

    public static function atualizarPlanoUsuario($pdo, $id_usuario, $plano) {
        $sql = "UPDATE usuarios SET plano_atual = ? WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        return $stmt->execute([$plano, $id_usuario]);
    }
    
    public static function obterAssinaturaAtual($pdo, $id_usuario) {
        $sql = "SELECT * FROM assinaturas WHERE id_usuario = ? AND status_pagamento = 'pago' ORDER BY data_pagamento DESC LIMIT 1";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$id_usuario]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>