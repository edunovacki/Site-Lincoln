<?php
session_start();
include 'conexao.php';
include 'classes/Assinatura.php';

// Verificar se usuário está logado
if (!isset($_SESSION['usuario'])) {
    header("Location: entrar.php");
    exit();
}

$plano = $_GET['plano'] ?? '';
$valores = [
    'Essencial' => 119.90,
    'Avancado' => 99.90,
    'Premium' => 79.90
];
$valor = $valores[$plano] ?? 0;

// Verificar se o usuário já tem uma assinatura ativa
$assinaturaAtual = Assinatura::obterAssinaturaAtual($pdo, $_SESSION['usuario']['id']);

// Gerar transação única
$transacao = uniqid();

// Salvar no banco de dados usando POO
try {
    $assinatura = new Assinatura([
        'id_usuario' => $_SESSION['usuario']['id'],
        'plano' => $plano,
        'valor' => $valor,
        'transacao' => $transacao
    ]);
    
    if ($assinatura->salvar($pdo)) {
        // Salvar a transação na sessão para possível cancelamento
        $_SESSION['transacao_andamento'] = $transacao;
        $_SESSION['plano_andamento'] = $plano;
    } else {
        throw new Exception("Erro ao salvar assinatura");
    }
} catch (Exception $e) {
    error_log("Erro ao processar assinatura: " . $e->getMessage());
    header("Location: erro.php?codigo=1");
    exit();
}

// Processar cancelamento
if (isset($_POST['cancelar'])) {
    try {
        Assinatura::cancelarAssinatura($pdo, $_SESSION['transacao_andamento']);
        unset($_SESSION['transacao_andamento']);
        unset($_SESSION['plano_andamento']);
        header("Location: index.php");
        exit();
    } catch (Exception $e) {
        error_log("Erro ao cancelar assinatura: " . $e->getMessage());
    }
}

// Processar finalização
if (isset($_POST['finalizar'])) {
    try {
        // Marcar como pago e cancelar assinaturas anteriores
        Assinatura::marcarComoPago($pdo, $_SESSION['transacao_andamento'], $_SESSION['usuario']['id']);
        
        // Atualizar plano do usuário
        Assinatura::atualizarPlanoUsuario($pdo, $_SESSION['usuario']['id'], $_SESSION['plano_andamento']);
        
        // Atualizar sessão do usuário
        $_SESSION['usuario']['plano_atual'] = $_SESSION['plano_andamento'];
        
        unset($_SESSION['transacao_andamento']);
        unset($_SESSION['plano_andamento']);
        
        header("Location: compra_finalizada.php?plano=" . urlencode($plano));
        exit();
    } catch (Exception $e) {
        error_log("Erro ao finalizar assinatura: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagamento - <?php echo htmlspecialchars($plano); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="CSS/pagamento.css" />
</head>
<body>
    <div class="container">
        <h1>Plano <?php echo htmlspecialchars($plano); ?> - R$ <?php echo number_format($valor, 2, ',', '.'); ?></h1>
        <p>Escaneie o QR Code abaixo para pagar via PIX</p>
        <div class="qrcode-container">
            <!-- QR Code removido conforme solicitado -->
            <div style="width: 200px; height: 200px; background-color: #f0f0f0; display: flex; justify-content: center; align-items: center; margin: 0 auto;">
                <span>QR Code não disponível</span>
            </div>
        </div>
        <div class="chave-pix">
            <p>Chave PIX: <span id="chave">2dab3619-c348-4040-8ce3-6b064d5302b2</span> <button onclick="copiarChave()">Copiar</button></p>
        </div>
        <form method="post">
            <div class="botoes-pagamento">
                <button type="submit" name="cancelar" class="btn-cancelar">Cancelar</button>
                <button type="submit" name="finalizar" class="btn-finalizar">Finalizar pagamento</button>
            </div>
        </form>
    </div>

    <script>
        function copiarChave() {
            const chave = document.getElementById('chave').innerText;
            navigator.clipboard.writeText(chave).then(() => {
                alert('Chave PIX copiada!');
            });
        }
    </script>
</body>
</html>