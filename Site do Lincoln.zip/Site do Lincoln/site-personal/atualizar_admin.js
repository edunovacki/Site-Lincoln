// Script para atualizar as estatísticas do admin em tempo real
function atualizarEstatisticas() {
    fetch('atualizar_estatisticas.php')
        .then(response => response.json())
        .then(data => {
            document.querySelector('[data-lucro]').textContent = `R$ ${data.lucro}`;
            document.querySelector('[data-assinaturas]').textContent = data.total_assinaturas;
        })
        .catch(error => console.error('Erro ao atualizar estatísticas:', error));
}

// Atualizar a cada 30 segundos
setInterval(atualizarEstatisticas, 30000);