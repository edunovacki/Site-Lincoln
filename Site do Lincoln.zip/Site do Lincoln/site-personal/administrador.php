<?php
session_start();
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: index.php");
    exit();
}

include 'conexao.php';

// Buscar estatísticas atualizadas (apenas assinaturas pagas)
$stmt = $pdo->query("SELECT COUNT(*) as total FROM assinaturas WHERE status_pagamento = 'pago'");
$total_assinaturas = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT SUM(valor) as lucro FROM assinaturas WHERE status_pagamento = 'pago'");
$lucro = $stmt->fetch()['lucro'];

// Buscar apenas as assinaturas relevantes (apenas as finalizadas)
$stmt = $pdo->query("
    SELECT a.id, a.plano, a.valor, a.status_pagamento, a.data_pagamento, u.nome as usuario_nome 
    FROM assinaturas a 
    JOIN usuarios u ON a.id_usuario = u.id
    WHERE a.status_pagamento IN ('pago', 'cancelado')
    ORDER BY a.data_pagamento DESC
");
$assinaturas = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrador</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="CSS/administrador.css">
</head>
<body>
    <div class="admin-container">
        <div class="sidebar">
            <h2>Admin</h2>
            <ul>
                <li><a href="#" class="active" data-target="lucro">Lucro</a></li>
                <li><a href="javascript:void(0)" onclick="window.location.href='index.php'; sessionStorage.setItem('forceLogout', 'true');">Sair</a></li>
            </ul>
        </div>
        <div class="main-content">
            <div class="stats">
                <div class="stat-card">
                    <h3>Lucro Total</h3>
                    <p>R$ <?php echo number_format($lucro, 2, ',', '.'); ?></p>
                </div>
                <div class="stat-card">
                    <h3>Total de Assinaturas</h3>
                    <p><?php echo $total_assinaturas; ?></p>
                </div>
            </div>
            <div class="content-section" id="lucro">
                <h2>Lista de Assinaturas Finalizadas</h2>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>Plano</th>
                            <th>Valor</th>
                            <th>Data Pagamento</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($assinaturas) > 0): ?>
                            <?php foreach ($assinaturas as $assinatura): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($assinatura['usuario_nome']); ?></td>
                                <td><?php echo htmlspecialchars($assinatura['plano']); ?></td>
                                <td>R$ <?php echo number_format($assinatura['valor'], 2, ',', '.'); ?></td>
                                <td><?php echo date('d/m/Y H:i', strtotime($assinatura['data_pagamento'])); ?></td>
                                <td>
                                    <span class="status <?php echo $assinatura['status_pagamento']; ?>">
                                        <?php 
                                        if ($assinatura['status_pagamento'] == 'pago') {
                                            echo 'Concluído';
                                        } else {
                                            echo 'Cancelado';
                                        }
                                        ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center">Nenhuma assinatura finalizada encontrada.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.querySelectorAll('.sidebar a').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const target = this.getAttribute('data-target');
                document.querySelectorAll('.content-section').forEach(section => {
                    section.style.display = 'none';
                });
                document.getElementById(target).style.display = 'block';
                document.querySelectorAll('.sidebar a').forEach(a => a.classList.remove('active'));
                this.classList.add('active');
            });
        });
    </script>
</body>
</html>