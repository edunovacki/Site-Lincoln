<?php
include 'conexao.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
    $nome = $_POST['nome'];
    $idade = $_POST['idade'];
    $sexo = $_POST['sexo'];

    try {
        $stmt = $pdo->prepare("INSERT INTO usuarios (email, senha, nome, idade, sexo) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$email, $senha, $nome, $idade, $sexo]);
        
        // Buscar usuário recém-criado e fazer login automático
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ?");
        $stmt->execute([$email]);
        $usuario = $stmt->fetch();
        
        session_start();
        $_SESSION['usuario'] = $usuario;
        
        header("Location: index.php");
        exit();
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            $erro = "Email já cadastrado.";
        } else {
            $erro = "Erro ao cadastrar. Tente novamente.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="CSS/cadastrar.css"/>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Bangers&family=Edu+VIC+WA+NT+Hand:wght@400..700&display=swap" rel="stylesheet">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Bangers&family=Edu+VIC+WA+NT+Hand:wght@400..700&family=IBM+Plex+Sans:ital,wght@0,100..700;1,100..700&display=swap" rel="stylesheet">
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel="stylesheet">
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

  <title>Personal Trainer</title>

</head>
<div class="nav">
  <p>Já possui uma conta? <a href="entrar.php">Login <i class="fa-solid fa-arrow-right"></i></a></p>
</div>

<body>
  
  <main class="container">
    <form action="cadastrar.php" method="post" id="formulario">
      <h1>Cadastre-se</h1>
      <div class="input-box"><input name="email" placeholder="E-mail" type="text" id="email" title="Por favor, insira um e-mail válido (ex: exemplo@site.com)" required><i class="fa-solid fa-at"></i>
      <?php if (isset($erro) && $erro != ''): ?>
        <div class="alert" role="alert">
            <?php echo $erro; ?>
        </div>
    <?php endif; ?>
    </div>
      <div class="input-box"><input name="senha" placeholder="Senha" type="password" minlength="4" required><i class="fa-solid fa-lock"></i></div>
      <div class="input-box"><input name="nome" placeholder="Nome Completo" type="text" required><i class="fa-solid fa-user"></i></div>
      <div class="input-box"><input name="idade" placeholder="Idade" type="text" maxlength="3" required><i class="fa-solid fa-calendar-days"></i></div>
      <div class="input-box"><input name="sexo" placeholder="Sexo(M/F)" type="text" pattern="[MF]" maxlength="1" id="sexo" required><i class="fa-solid fa-venus-mars"></i></div>
      <button type="submit" class="login" href="index.php">Criar conta</button>
    </form>
  </main>
</br>
  <!--<?php
      include 'footer.php';
      ?>!-->
  <script src="https://kit.fontawesome.com/83f4c4a578.js" crossorigin="anonymous"></script>
  <script>
    AOS.init();
  </script>
  <script>
      //SEXO

      const sexoInput = document.getElementById("sexo");

      sexoInput.addEventListener("input", () => {
        let value = sexoInput.value.toUpperCase(); // força maiúscula
        if (value !== "M" && value !== "F") {
          sexoInput.value = ""; // limpa se não for M ou F
        } else {
          sexoInput.value = value; // mantém válido
        }
      });

      //EMAIL

      const email = document.getElementById("email");
      const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\.[a-zA-Z]{2,})?$/;

      email.addEventListener("input", function () {
        if (emailRegex.test(email.value)) {
          email.setCustomValidity(""); // válido → sem mensagem
        } else {
          email.setCustomValidity("Por favor, insira um e-mail válido (ex: exemplo@site.com)");
          }
      });
    </script>
    <script>
// Limpar parâmetros da URL ao carregar a página
if (window.history.replaceState) {
    window.history.replaceState(null, null, window.location.href.split('?')[0]);
}
</script> 
</body>

</html>