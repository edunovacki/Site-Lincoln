<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: entrar.php");
    exit();
}

$plano = $_GET['plano'] ?? '';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Compra Finalizada</title>
    <link rel="stylesheet" href="CSS/compra_finalizada.css"/>
</head>
<body>
    <div class="container">
        <div class="icone-sucesso">
            <i class="fas fa-check-circle"></i>
        </div>
        <h1>Compra Finalizada com Sucesso!</h1>
        <p>Obrigado por assinar o plano <?php echo htmlspecialchars($plano); ?>.</p>
        <p>Seu plano já está ativo e você pode começar a usufruir dos benefícios.</p>
        <a href="index.php" class="btn-voltar">Voltar à Página Inicial</a>
    </div>
    <script src="https://kit.fontawesome.com/83f4c4a578.js" crossorigin="anonymous"></script>
</body>
</html>