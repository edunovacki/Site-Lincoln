<?php
session_start();
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("HTTP/1.1 403 Forbidden");
    exit();
}

include 'conexao.php';

$stmt = $pdo->query("SELECT COUNT(*) as total FROM assinaturas WHERE status_pagamento = 'pago'");
$total_assinaturas = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT SUM(valor) as lucro FROM assinaturas WHERE status_pagamento = 'pago'");
$lucro = $stmt->fetch()['lucro'];

header('Content-Type: application/json');
echo json_encode([
    'total_assinaturas' => $total_assinaturas,
    'lucro' => number_format($lucro, 2, ',', '.')
]);
?>